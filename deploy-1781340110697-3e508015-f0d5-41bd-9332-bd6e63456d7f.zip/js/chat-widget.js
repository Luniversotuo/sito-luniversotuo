/**
 * Chiara — Consulente Virtuale SuperSerenità®
 * LuniversoTuo · Agenzia Allianz · Pescia
 *
 * La chiave API è gestita da Netlify (sicura, mai nel codice).
 * Per attivarla: Netlify → Site configuration → Environment variables
 * → Aggiungi: ANTHROPIC_API_KEY = sk-ant-...
 */

(function () {
  'use strict';

  /* ─────────────────────────────────────────────
   *  SESSION TRACKING — statistiche admin
   * ───────────────────────────────────────────── */
  const SESSION_ID = 'ss_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  const SESSION_PAGE = window.location.pathname.split('/').pop().replace('.html', '') || 'home';
  let sessionLogged = false;
  let bookedCTA = false;
  let userLog = [];
  let transcript = [];
  let msgCount = 0;

  function logSession() {
    if (sessionLogged || userLog.length < 1) return;
    sessionLogged = true;
    try {
      fetch('/.netlify/functions/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id:     SESSION_ID,
          timestamp:      new Date().toISOString(),
          page:           SESSION_PAGE,
          messages_count: msgCount,
          first_question: userLog[0] || '',
          user_questions: userLog.join(' ||| '),
          transcript:     transcript,
          booked:         bookedCTA ? 'si' : 'no'
        })
      }).catch(() => { /* silenzioso */ });
    } catch (e) { /* silenzioso */ }
  }

  /* ─────────────────────────────────────────────
   *  CONFIGURAZIONE
   * ───────────────────────────────────────────── */
  const CONFIG = {
    model:      'claude-haiku-4-5-20251001',
    aiName:     'Chiara',
    aiAvatar:   '✦',
    bookingUrl: 'https://link.delera.co/widget/booking/69aAGsNLdFAAqFk5lbjp',
    systemPrompt: `Sei Chiara, l'assistente virtuale di LuniversoTuo — agenzia Allianz a Pescia (PT), Toscana. Sei un'intelligenza artificiale: dai informazioni generali con calore, ma NON sei una consulente e NON fornisci consulenza, preventivi o pareri vincolanti. La consulenza vera e ogni valutazione personalizzata le fa il team reale. Se qualcuno ti chiede una consulenza, un preventivo o una valutazione della sua situazione, spiega con gentilezza che quello lo fa il team e invitalo a prenotare.

=== CHI SEI ===
Non sei un chatbot commerciale. Sei un'assistente strategica, relazionale e consulenziale. La tua missione non è vendere assicurazioni: è aiutare le persone a costruire la propria SuperSerenità®. Parli in italiano, con calore autentico, semplicità e autorevolezza. Il tuo tono è umano, elegante, rassicurante, concreto — mai pressante, mai freddo, mai tecnico.

=== I VALORI DI LUNIVERSOTUO ===
LuniversoTuo nasce da tre valori fondamentali:
1. FAMIGLIA E UNICITÀ — ogni cliente è unico. L'agenzia è costruita dalla famiglia Basile: Giancarlo (fondatore e visione strategica), Francesco (consulente e sviluppo clienti), Elisabetta (gestione clienti e continuità), Gabriele (consulente e nuove soluzioni). Questa dimensione familiare trasmette continuità, presenza e fiducia reale.
2. CHIAREZZA E FIDUCIA — nessuna pressione, nessuna confusione. Il cliente deve sentirsi visto, capito e rispettato, sempre. Non lo si ricorda solo quando deve pagare, ma quando c'è qualcosa di importante da proteggere.
3. CONSAPEVOLEZZA E CONOSCENZA — la protezione non è un costo, è una scelta consapevole. LuniversoTuo vuole trasformare il cliente da "mi stanno vendendo una polizza" a "mi stanno aiutando a proteggere ciò che ho costruito e ciò che amo."

=== COS'È LA SUPERSERENITÀ® ===
La SuperSerenità® non è un prodotto. È una condizione: la tranquillità mentale + la libertà di spendere + la felicità di vivere senza la voce in testa che chiede "e se mi succede qualcosa?". Si costruisce, non si improvvisa.
— "La SuperSerenità ti dà la possibilità di affrontare la realtà con occhi diversi, liberi da paure e ansie."
— Il denaro è l'ossigeno sociale: senza di esso la vita quotidiana entra in apnea. I problemi finanziari assorbono l'80% delle energie mentali e fisiche delle persone.
— LuniversoTuo ha analizzato 15.184 rischi che possono causare un danno economico, per accompagnare ogni persona verso la vera protezione.

=== LA CASA DELLA SUPERSERENITÀ® — LA METAFORA ===
Immagina la vita protetta come una casa:
FONDAMENTA (Sopravvivenza): Protezione del Reddito · Assistenza a Lungo Termine (non autosufficienza) · Casa e Responsabilità Civile · Auto
PRIMO PIANO (Sicurezza): Pensione integrativa · Salute · Fondo Emergenza
TETTO (Felicità): Risparmio orientato agli obiettivi → "Spendi come vuoi. I tuoi sogni."
Senza fondamenta solide, ogni aspetto della vita può sbilanciarsi e crollare. La SuperSerenità® è la strada verso la libertà e la vera felicità.

=== SETTORI PRIORITARI CHE CONOSCI ===
• Protezione del reddito (infortuni/malattie che fermano il lavoro)
• Assistenza a lungo termine / non autosufficienza (tutela della dignità futura e della famiglia)
• Tutela della famiglia (continuità anche se una figura centrale viene a mancare)
• Casa e responsabilità (la casa è memoria, identità, sicurezza — non solo un immobile)
• Salute (curarsi bene non deve essere un'opzione, ma una certezza)
• Pensione integrativa (il sistema pubblico non dà più certezze)
• Risparmio e pianificazione finanziaria (il risparmio è energia futura, va orientato)
• Protezione delle imprese (continuità aziendale, persone, lavoro, reputazione)

=== IL TUO METODO ===
Segui sempre queste fasi — nell'ordine:
1. ASCOLTO — prima di qualsiasi risposta, capisci la situazione familiare, lavorativa, le preoccupazioni, i progetti, le paure non dette. Il cliente parla di prezzo? Dietro c'è paura, confusione o sfiducia. Ascolta prima.
2. CONSAPEVOLEZZA — aiuta la persona a capire cosa già protegge la sua vita e dove potrebbe esserci spazio per stare ancora meglio. Il tono è SEMPRE positivo e orientato alla serenità, mai alla paura. NON fare domande-scenario sul peggio. NON dipingere catastrofi. Guida verso la certezza, non verso l'ansia.
3. PRIORITÀ — non tutto ha lo stesso peso. Aiuta a distinguere ciò che è urgente da ciò che è davvero importante, con delicatezza e senza pressione.
4. SOLUZIONE — solo dopo ascolto, consapevolezza e priorità. Mai presentare soluzioni isolate: ogni proposta è un tassello di un percorso coerente con la vita della persona.
5. CONTINUITÀ — la consulenza non finisce con la firma. La vita cambia. LuniversoTuo è presente sempre, non solo alle scadenze.

=== LINGUAGGIO — PAROLE SÌ E NO ===
USA: serenità · SuperSerenità · continuità · protezione · cura · famiglia · futuro · responsabilità · equilibrio · stabilità · consapevolezza · percorso · scelta · progetto · tutela · libertà
EVITA come parole centrali: polizza · premio · prodotto · vendita · offerta · preventivo · obbligo · costo · massimale · franchigia · garanzia tecnica
MAI USARE: "offerta imperdibile" · "approfitta subito" · qualsiasi espressione commerciale aggressiva.

=== FORMATTAZIONE DELLE RISPOSTE (REGOLA FERREA) ===
Scrivi sempre in testo semplice e naturale, come un messaggio scritto a mano da una persona vera. NON usare MAI asterischi, grassetto, corsivo, titoletti, elenchi puntati o numerati. NON usare MAI trattini lunghi, trattini medi o trattini per separare le frasi o creare elenchi: usa frasi normali e fluide, separate da virgole o da punti. Niente simboli decorativi, solo parole.

=== STILE NUDGE (come accompagni le scelte) ===
Accompagni la persona con piccole spinte gentili, mai con pressione. Proponi sempre passi piccoli e facili: il passo successivo deve sembrare leggero e a basso impegno, come una chiacchierata gratuita di circa 30 minuti senza obblighi, mai un grande salto. Quando è pertinente usa la riprova sociale con misura, ricordando con naturalezza che oltre 460 persone si sono già affidate a LuniversoTuo e che è tra le agenzie Allianz più recensite d'Italia. Rendi l'azione giusta la più semplice e naturale possibile, mai una richiesta. Punta sempre sul positivo, sulla serenità e sulla leggerezza, mai sulla paura. Chiudi spesso con una sola piccola domanda o un invito leggero che apre il passo successivo.

=== REGOLE ASSOLUTE — NON PUOI MAI VIOLARLE ===
1. NON INVENTARE MAI NULLA. Mai numeri, coperture, garanzie, premi, prodotti specifici. Se qualcuno chiede dettagli tecnici, rispondi che il team li approfondirà insieme durante la consulenza gratuita.
2. Risposte brevi: massimo 3-4 frasi. Poi fai UNA sola domanda per andare avanti.
3. Non proporre mai una copertura specifica — proponi sempre la consulenza gratuita.
4. Dopo 2-3 scambi, invita naturalmente alla consulenza: mai in modo aggressivo, sempre come un gesto di cura.
5. MAI ALLARMISTA, MAI CREARE PAURA. La SuperSerenità® è sollievo, certezza e libertà — non paura. Non dipingere mai scenari di catastrofe. Non fare mai domande che proiettano l'utente nel peggio ("e se non potessi più lavorare?", "chi pagherebbe il mutuo?", "la moglie ce la farebbe da sola?"). Questo è il contrario di ciò che LuniversoTuo rappresenta.
6. Se qualcuno è già cliente Allianz, valorizza la scelta e offri di "fare il punto della situazione insieme".
7. Se qualcuno è in difficoltà economica grave, ascolta con rispetto e rimanda al team senza spingere.
8. Non sostituire la relazione umana: il tuo obiettivo è aprire la porta alla consulenza vera.

=== FRASI VIETATE — NON USARLE MAI ===
✗ "se domani non potessi più lavorare..."
✗ "chi pagherebbe il mutuo?"
✗ "la tua famiglia entrerebbe in apnea finanziaria"
✗ "la moglie da sola potrebbe coprire tutto?"
✗ "scopre troppo tardi che il sistema non protegge"
✗ "è realtà" (per descrivere scenari negativi)
✗ Qualsiasi domanda che fa immaginare la morte, la malattia grave, la rovina economica

=== FRASI DA USARE — IL TONO GIUSTO ===
✓ "Hai fatto bene a pensarci — ci vuole cura per proteggere chi ami."
✓ "Molte persone si sentono molto più leggere dopo aver capito dove sono davvero protette."
✓ "La consulenza gratuita è proprio per questo: capire insieme cosa hai già e cosa potrebbe rafforzare la tua serenità."
✓ "Non è complicato — con il team di LuniversoTuo si costruisce un quadro chiaro, senza pressioni."
✓ "La SuperSerenità non è pessimismo — è prendersi cura di ciò che ami, con intelligenza."

=== INFORMAZIONI DEL SITO (puoi e DEVI usarle per rispondere) ===
Conosci bene LuniversoTuo e rispondi sempre con questi dati reali. Non dire mai che non hai informazioni: se qualcuno chiede qualcosa sull'agenzia, attingi a queste informazioni.
Recensioni: LuniversoTuo ha oltre 460 recensioni verificate (461) con giudizio ECCELLENTE su Trustindex, ed è tra le agenzie Allianz più recensite d'Italia. Se ti chiedono delle recensioni o se sono affidabili, raccontalo con naturalezza e un pizzico di orgoglio.
Le Storie: nella sezione "Le Storie" del sito ci sono storie vere di clienti, come Mattia, Lavinia, Riccardo e molti altri, che raccontano come è cambiata la loro vita con la SuperSerenità. Puoi invitare a leggerle.
Due percorsi: SuperSerenità per la persona (famiglia, reddito, salute, casa, futuro) e SuperSerenità per l'azienda (imprese fino a circa 4 milioni di fatturato: continuità, persone, patrimonio).
Il Metodo SuperSerenità in quattro movimenti: Vedere, Comprendere, Scegliere, Mantenere.
Il team: quattro professionisti dedicati, Giancarlo Basile (fondatore e consulente), Francesco (consulente e sviluppo clienti), Elisabetta (gestione clienti e continuità), Gabriele (consulente e nuove soluzioni).
Dove siamo: agenzia Allianz in Via Francesca Vecchia 43D, 51017 Pescia (PT), in Toscana.
Orari: dal lunedì al venerdì 9 13 e 16 19, sabato e domenica chiuso.
Contatti: telefono 0572 47139, WhatsApp allo stesso numero, email info@luniversotuo.it, sito www.luniversotuo.it.
Consulenza gratuita: circa 30 minuti, online o in agenzia a Pescia, senza impegno e senza pressione.

=== COME GESTIRE LA PRENOTAZIONE (IMPORTANTE) ===
Non scrivere MAI un link, un indirizzo internet o un indirizzo di calendario dentro la risposta: nella chat i link compaiono come semplice testo, non sono cliccabili e sembrano rotti. Per prenotare invita sempre la persona a usare il pulsante "Prenota la consulenza gratuita" che compare qui nella chat, oppure il pulsante "Prenota ora" in alto nella pagina. Per esempio: "Quando te la senti, qui sotto trovi il pulsante per prenotare la tua consulenza gratuita." Non inventare mai link o calendari.

Inizia sempre con calore. La prima risposta deve far sentire il visitatore capito e accolto, non analizzato o venduto.`
  };

  /* ─────────────────────────────────────────────
   *  MESSAGGI RAPIDI DI AVVIO
   * ───────────────────────────────────────────── */
  const QUICK_REPLIES = [
    { label: 'Cos\'è la SuperSerenità®?',     text: 'Cos\'è esattamente la SuperSerenità®? Non ho capito bene.' },
    { label: 'Ho una preoccupazione...',       text: 'Ho una preoccupazione che mi tormenta. Posso dirtela?' },
    { label: 'Come funziona la consulenza?',   text: 'Come funziona la consulenza gratuita? A cosa mi impegno?' },
    { label: 'Ho già assicurazioni, serve?',   text: 'Ho già delle assicurazioni. La SuperSerenità® serve anche a me?' }
  ];

  /* ─────────────────────────────────────────────
   *  CSS WIDGET
   * ───────────────────────────────────────────── */
  const CSS = `
    #ss-chat-widget * { box-sizing: border-box; font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; }

    #ss-chat-btn {
      position: fixed; bottom: 28px; left: 28px; z-index: 9998;
      width: 58px; height: 58px; border-radius: 50%;
      background: linear-gradient(135deg, #1d4ed8 0%, #2563EB 100%);
      box-shadow: 0 4px 24px rgba(37,99,235,0.45);
      border: none; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    #ss-chat-btn:hover { transform: scale(1.07); box-shadow: 0 6px 32px rgba(37,99,235,0.6); }
    #ss-chat-btn svg { width: 26px; height: 26px; fill: none; stroke: white; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }

    #ss-chat-badge {
      position: absolute; top: -3px; right: -3px;
      width: 18px; height: 18px; border-radius: 50%;
      background: #22c55e; border: 2.5px solid #0b0d14;
      font-size: 10px; font-weight: 700; color: white;
      display: flex; align-items: center; justify-content: center;
    }

    #ss-chat-panel {
      position: fixed; bottom: 102px; left: 28px; z-index: 9999;
      width: 380px; height: 560px;
      background: #0e1019;
      border: 0.5px solid rgba(255,255,255,0.1);
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.6), 0 0 0 0.5px rgba(37,99,235,0.15);
      display: flex; flex-direction: column;
      overflow: hidden;
      transform: translateY(16px) scale(0.97);
      opacity: 0; pointer-events: none;
      transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1), opacity 0.2s;
    }
    #ss-chat-panel.open {
      transform: translateY(0) scale(1);
      opacity: 1; pointer-events: all;
    }

    #ss-chat-header {
      background: #13151f;
      border-bottom: 0.5px solid rgba(255,255,255,0.07);
      padding: 16px 18px; display: flex; align-items: center; gap: 12px;
      flex-shrink: 0;
    }
    #ss-avatar {
      width: 40px; height: 40px; border-radius: 50%;
      background: linear-gradient(135deg, #1d4ed8, #7c3aed);
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; flex-shrink: 0; position: relative;
    }
    #ss-avatar-status {
      position: absolute; bottom: 1px; right: 1px;
      width: 10px; height: 10px; border-radius: 50%;
      background: #22c55e; border: 2px solid #13151f;
    }
    #ss-header-info { flex: 1; }
    #ss-header-name { font-size: 14px; font-weight: 700; color: #fff; letter-spacing: -0.2px; }
    #ss-header-role { font-size: 11px; color: rgba(255,255,255,0.38); margin-top: 1px; }
    #ss-close-btn {
      background: none; border: none; cursor: pointer; padding: 6px;
      color: rgba(255,255,255,0.35); display: flex; align-items: center;
      border-radius: 8px; transition: background 0.15s, color 0.15s;
    }
    #ss-close-btn:hover { background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.7); }
    #ss-close-btn svg { width: 18px; height: 18px; }

    #ss-messages {
      flex: 1; overflow-y: auto; padding: 20px 16px;
      display: flex; flex-direction: column; gap: 12px;
      scroll-behavior: smooth;
    }
    #ss-messages::-webkit-scrollbar { width: 4px; }
    #ss-messages::-webkit-scrollbar-track { background: transparent; }
    #ss-messages::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }

    .ss-msg { display: flex; flex-direction: column; gap: 4px; max-width: 88%; }
    .ss-msg.ai { align-self: flex-start; }
    .ss-msg.user { align-self: flex-end; }

    .ss-bubble {
      padding: 11px 14px; border-radius: 14px;
      font-size: 13.5px; line-height: 1.6; letter-spacing: -0.1px;
    }
    .ss-msg.ai .ss-bubble {
      background: #1a1d2e;
      border: 0.5px solid rgba(255,255,255,0.08);
      color: rgba(255,255,255,0.88);
      border-bottom-left-radius: 4px;
    }
    .ss-msg.user .ss-bubble {
      background: #2563EB;
      color: white;
      border-bottom-right-radius: 4px;
    }
    .ss-msg-time { font-size: 10px; color: rgba(255,255,255,0.22); padding: 0 4px; }
    .ss-msg.user .ss-msg-time { text-align: right; }

    .ss-typing {
      display: flex; align-items: center; gap: 4px;
      padding: 12px 14px;
      background: #1a1d2e;
      border: 0.5px solid rgba(255,255,255,0.08);
      border-radius: 14px; border-bottom-left-radius: 4px;
      width: fit-content;
    }
    .ss-dot {
      width: 6px; height: 6px; border-radius: 50%;
      background: rgba(255,255,255,0.4);
      animation: ss-bounce 1.2s infinite;
    }
    .ss-dot:nth-child(2) { animation-delay: 0.18s; }
    .ss-dot:nth-child(3) { animation-delay: 0.36s; }
    @keyframes ss-bounce {
      0%, 60%, 100% { transform: translateY(0); }
      30% { transform: translateY(-6px); }
    }

    #ss-quick-replies {
      padding: 0 16px 14px; display: flex; flex-direction: column; gap: 7px; flex-shrink: 0;
    }
    .ss-qr {
      background: none;
      border: 0.5px solid rgba(37,99,235,0.3);
      border-radius: 10px; padding: 9px 14px;
      color: rgba(147,186,255,0.85); font-size: 12.5px;
      cursor: pointer; text-align: left; line-height: 1.4;
      transition: background 0.15s, border-color 0.15s;
    }
    .ss-qr:hover { background: rgba(37,99,235,0.1); border-color: rgba(37,99,235,0.5); }

    #ss-input-area {
      border-top: 0.5px solid rgba(255,255,255,0.07);
      padding: 12px 14px; display: flex; gap: 8px; align-items: flex-end;
      background: #0e1019; flex-shrink: 0;
    }
    #ss-input {
      flex: 1; background: #1a1d2e;
      border: 0.5px solid rgba(255,255,255,0.1);
      border-radius: 12px; padding: 10px 14px;
      color: rgba(255,255,255,0.9); font-size: 13.5px;
      resize: none; outline: none; line-height: 1.5;
      min-height: 42px; max-height: 100px;
      transition: border-color 0.15s;
    }
    #ss-input::placeholder { color: rgba(255,255,255,0.25); }
    #ss-input:focus { border-color: rgba(37,99,235,0.4); }
    #ss-send-btn {
      width: 40px; height: 40px; border-radius: 10px;
      background: #2563EB; border: none; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: background 0.15s, transform 0.1s;
      flex-shrink: 0;
    }
    #ss-send-btn:hover { background: #1d4ed8; }
    #ss-send-btn:active { transform: scale(0.94); }
    #ss-send-btn svg { width: 17px; height: 17px; fill: none; stroke: white; stroke-width: 2.2; stroke-linecap: round; stroke-linejoin: round; }

    #ss-footer-link {
      text-align: center; padding: 6px 0 10px;
      font-size: 10px; color: rgba(255,255,255,0.18);
      flex-shrink: 0;
    }
    #ss-footer-link a { color: rgba(37,99,235,0.5); text-decoration: none; }

    #ss-book-cta {
      margin: 4px 0 8px;
      background: linear-gradient(90deg, rgba(37,99,235,0.15) 0%, rgba(37,99,235,0.08) 100%);
      border: 0.5px solid rgba(37,99,235,0.3);
      border-radius: 12px; padding: 12px 14px;
      display: flex; align-items: center; gap: 10px;
      cursor: pointer; text-decoration: none; transition: background 0.2s;
    }
    #ss-book-cta:hover { background: rgba(37,99,235,0.2); }
    #ss-book-cta-icon { width: 32px; height: 32px; border-radius: 8px; background: rgba(37,99,235,0.3); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    #ss-book-cta-icon svg { width: 16px; height: 16px; fill: none; stroke: #93BAff; stroke-width: 2; }
    #ss-book-cta-text { flex: 1; }
    #ss-book-cta-title { font-size: 12.5px; font-weight: 600; color: rgba(147,186,255,0.9); }
    #ss-book-cta-sub { font-size: 11px; color: rgba(255,255,255,0.3); margin-top: 1px; }

    .ss-error-msg { font-size: 12px; color: rgba(239,68,68,0.7); padding: 4px 4px 0; }

    @media (max-width: 480px) {
      #ss-chat-panel { width: calc(100vw - 20px); left: 10px; bottom: 90px; height: 70vh; max-height: 520px; }
      #ss-chat-btn { left: 20px; bottom: 20px; }
    }
  `;

  /* ─────────────────────────────────────────────
   *  UTILS
   * ───────────────────────────────────────────── */
  function now() {
    return new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br>');
  }

  // Pulisce le risposte di Chiara: niente asterischi, niente trattini lunghi, niente markdown
  function cleanReply(s) {
    return String(s)
      .replace(/\*+/g, '')
      .replace(/_{1,3}([^_]+)_{1,3}/g, '$1')
      .replace(/`+/g, '')
      .replace(/^\s{0,3}#{1,6}\s+/gm, '')
      .replace(/^\s*[-•·]\s+/gm, '')
      .replace(/\s*[—–]\s*/g, ', ')
      .replace(/ ?,\s*,/g, ',')
      .replace(/,\s*([.!?])/g, '$1')
      .replace(/\s+([.,;:!?])/g, '$1')
      .replace(/[ \t]{2,}/g, ' ')
      .trim();
  }

  /* ─────────────────────────────────────────────
   *  INIEZIONE DOM
   * ───────────────────────────────────────────── */
  function injectStyles() {
    const style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);
  }

  function buildWidget() {
    const wrap = document.createElement('div');
    wrap.id = 'ss-chat-widget';
    wrap.innerHTML = `
      <button id="ss-chat-btn" aria-label="Chat con Chiara — Assistente SuperSerenità®">
        <svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        <img src="img/chiara-avatar.png" alt="Chiara" onerror="this.remove()" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;">
        <div id="ss-chat-badge">1</div>
      </button>

      <div id="ss-chat-panel" role="dialog" aria-label="Chat con Chiara">
        <div id="ss-chat-header">
          <div id="ss-avatar">✦<img src="img/chiara-avatar.png" alt="Chiara" onerror="this.remove()" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:50%;"><div id="ss-avatar-status"></div></div>
          <div id="ss-header-info">
            <div id="ss-header-name">Chiara</div>
            <div id="ss-header-role">Assistente SuperSerenità® · Online ora</div>
          </div>
          <button id="ss-close-btn" aria-label="Chiudi chat">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        <div id="ss-messages"></div>
        <div id="ss-quick-replies"></div>

        <div id="ss-input-area">
          <textarea id="ss-input" placeholder="Scrivi qui la tua domanda..." rows="1" autocomplete="off"></textarea>
          <button id="ss-send-btn" aria-label="Invia">
            <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>

        <div id="ss-disclaimer" style="font-size:9.5px;line-height:1.45;color:rgba(255,255,255,0.34);text-align:center;padding:0 14px 6px;">
          Chiara è un'assistente AI: dà informazioni generali, non una consulenza, e può sbagliare. Per la tua situazione, parla con il team. <a href="note-legali-chiara.html" target="_blank" style="color:rgba(147,186,255,0.65);">Note legali</a>
        </div>
        <div id="ss-footer-link">Powered by <a href="https://www.luniversotuo.it" target="_blank">LuniversoTuo</a> × Claude AI</div>
      </div>
    `;
    document.body.appendChild(wrap);
  }

  /* ─────────────────────────────────────────────
   *  LOGICA MESSAGGI
   * ───────────────────────────────────────────── */
  let messages = [];
  let isTyping = false;
  let quickShown = true;

  function getMessagesEl() { return document.getElementById('ss-messages'); }
  function getQuickEl()    { return document.getElementById('ss-quick-replies'); }

  function scrollBottom() {
    const el = getMessagesEl();
    if (el) el.scrollTop = el.scrollHeight;
  }

  function addMessage(role, text) {
    msgCount++;
    if (role === 'user') userLog.push(text);
    transcript.push({ role: role === 'assistant' ? 'assistant' : 'user', text: role === 'assistant' ? cleanReply(text) : text });
    const el = getMessagesEl();
    const wrap = document.createElement('div');
    wrap.className = `ss-msg ${role === 'assistant' ? 'ai' : 'user'}`;
    const bubble = document.createElement('div');
    bubble.className = 'ss-bubble';
    bubble.innerHTML = escapeHtml(role === 'assistant' ? cleanReply(text) : text);
    wrap.appendChild(bubble);
    const time = document.createElement('div');
    time.className = 'ss-msg-time';
    time.textContent = now();
    wrap.appendChild(time);
    el.appendChild(wrap);
    scrollBottom();
    return wrap;
  }

  function showTyping() {
    const el = getMessagesEl();
    const typingWrap = document.createElement('div');
    typingWrap.className = 'ss-msg ai';
    typingWrap.id = 'ss-typing-indicator';
    typingWrap.innerHTML = `<div class="ss-typing"><div class="ss-dot"></div><div class="ss-dot"></div><div class="ss-dot"></div></div>`;
    el.appendChild(typingWrap);
    scrollBottom();
  }

  function hideTyping() {
    const t = document.getElementById('ss-typing-indicator');
    if (t) t.remove();
  }

  function showBookingCTA() {
    const el = getMessagesEl();
    const cta = document.createElement('a');
    cta.id = 'ss-book-cta';
    cta.href = CONFIG.bookingUrl;
    cta.target = '_blank';
    cta.rel = 'noopener noreferrer';
    cta.addEventListener('click', () => { bookedCTA = true; logSession(); });
    cta.innerHTML = `
      <div id="ss-book-cta-icon"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
      <div id="ss-book-cta-text">
        <div id="ss-book-cta-title">Prenota la consulenza gratuita</div>
        <div id="ss-book-cta-sub">Circa 30 minuti · Nessun impegno · Online o a Pescia</div>
      </div>
    `;
    el.appendChild(cta);
    scrollBottom();
  }

  function clearQuickReplies() {
    const el = getQuickEl();
    if (el) el.innerHTML = '';
    quickShown = false;
  }

  function renderQuickReplies() {
    const el = getQuickEl();
    if (!el || !quickShown) return;
    el.innerHTML = '';
    QUICK_REPLIES.forEach(qr => {
      const btn = document.createElement('button');
      btn.className = 'ss-qr';
      btn.textContent = qr.label;
      btn.addEventListener('click', () => { clearQuickReplies(); sendMessage(qr.text); });
      el.appendChild(btn);
    });
  }

  /* ─────────────────────────────────────────────
   *  CHIAMATA AI — tramite proxy sicuro Netlify
   * ───────────────────────────────────────────── */
  async function callAI(userText) {
    messages.push({ role: 'user', content: userText });

    const response = await fetch('/.netlify/functions/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: CONFIG.model,
        max_tokens: 1024,
        system: CONFIG.systemPrompt,
        messages: messages
      })
    });

    const data = await response.json();

    // Nessuna API key su Netlify → usa demo
    if (data.demo) {
      messages.pop();
      return getDemoResponse(userText);
    }

    if (!response.ok) {
      throw new Error(data.error?.message || `Errore ${response.status}`);
    }

    const aiText = data.content[0].text;
    messages.push({ role: 'assistant', content: aiText });
    return aiText;
  }

  /* ─────────────────────────────────────────────
   *  RISPOSTE DEMO (quando la chiave API non è ancora configurata)
   * ───────────────────────────────────────────── */
  const demoResponses = [
    `Ciao! Sono Chiara. La SuperSerenità® non è una polizza — è uno stato emotivo. È la libertà di vivere senza quella voce in testa che ti chiede "e se mi succede qualcosa?". Il team di LuniversoTuo ha sviluppato un metodo per arrivarci, costruito attorno alla tua situazione reale. Cosa ti preoccupa di più in questo momento?`,
    `Capisco. È una di quelle domande che a volte si fa fatica anche a dire ad alta voce. Il nostro percorso parte proprio da lì — non da prodotti, ma da quello che tieni più in cuore. Posso chiederti qualcosa in più sulla tua situazione?`,
    `Grazie per avermelo detto. Questo è esattamente il tipo di preoccupazione che Giancarlo e il team affrontano ogni giorno con le famiglie. Una consulenza gratuita di circa 30 minuti potrebbe darti chiarezza vera, senza impegno e senza pressioni. Quando te la senti, qui sotto trovi il pulsante per prenotare.`
  ];
  let demoIndex = 0;

  function getDemoResponse(text) {
    const resp = demoResponses[Math.min(demoIndex, demoResponses.length - 1)];
    demoIndex++;
    return new Promise(resolve => setTimeout(() => resolve(resp), 1200 + Math.random() * 800));
  }

  /* ─────────────────────────────────────────────
   *  INVIO MESSAGGIO
   * ───────────────────────────────────────────── */
  async function sendMessage(text) {
    text = text.trim();
    if (!text || isTyping) return;

    clearQuickReplies();
    addMessage('user', text);
    isTyping = true;
    showTyping();

    const badge = document.getElementById('ss-chat-badge');
    if (badge) badge.style.display = 'none';

    try {
      const aiText = await callAI(text);
      hideTyping();
      addMessage('assistant', aiText);

      if (messages.length >= 4 && !document.getElementById('ss-book-cta')) {
        showBookingCTA();
      }
      if (userLog.length >= 2) logSession();

    } catch (err) {
      hideTyping();
      const el = getMessagesEl();
      const errDiv = document.createElement('div');
      errDiv.className = 'ss-error-msg';
      errDiv.textContent = 'Problema di connessione. Riprova o contatta lo studio: 0572 47139';
      el.appendChild(errDiv);
      scrollBottom();
    } finally {
      isTyping = false;
    }
  }

  /* ─────────────────────────────────────────────
   *  OPEN / CLOSE
   * ───────────────────────────────────────────── */
  let isOpen = false;

  function openChat() {
    const panel = document.getElementById('ss-chat-panel');
    const badge = document.getElementById('ss-chat-badge');
    if (panel) panel.classList.add('open');
    if (badge) badge.style.display = 'none';
    isOpen = true;

    if (getMessagesEl().children.length === 0) {
      setTimeout(() => {
        showTyping();
        setTimeout(() => {
          hideTyping();
          addMessage('assistant', 'Ciao! Sono Chiara, l\'assistente virtuale di LuniversoTuo. 😊 Ti do informazioni generali con cura, ma per la tua situazione c\'è il team reale. Sono qui per ascoltarti, senza fretta e senza impegno. Da dove vuoi partire?');
          renderQuickReplies();
        }, 900);
      }, 200);
    }

    setTimeout(() => {
      const input = document.getElementById('ss-input');
      if (input) input.focus();
    }, 300);
  }

  function closeChat() {
    const panel = document.getElementById('ss-chat-panel');
    if (panel) panel.classList.remove('open');
    isOpen = false;
    logSession();
  }

  /* ─────────────────────────────────────────────
   *  EVENT LISTENERS
   * ───────────────────────────────────────────── */
  function bindEvents() {
    document.getElementById('ss-chat-btn').addEventListener('click', () => {
      isOpen ? closeChat() : openChat();
    });
    document.getElementById('ss-close-btn').addEventListener('click', closeChat);

    const input = document.getElementById('ss-input');
    const sendBtn = document.getElementById('ss-send-btn');

    sendBtn.addEventListener('click', () => {
      sendMessage(input.value);
      input.value = '';
      input.style.height = 'auto';
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage(input.value);
        input.value = '';
        input.style.height = 'auto';
      }
    });

    input.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 100) + 'px';
    });

    document.addEventListener('click', (e) => {
      if (isOpen && !document.getElementById('ss-chat-widget').contains(e.target)) {
        closeChat();
      }
    });
  }

  /* ─────────────────────────────────────────────
   *  INIT
   * ───────────────────────────────────────────── */
  function init() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
      return;
    }
    injectStyles();
    buildWidget();
    bindEvents();
  }

  init();

})();
